package com.madt.sree.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.wearable.activity.WearableActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Question_4 extends WearableActivity {

    private TextView mTextView;

    public int option_number = 0;
    public int score = 0;
    private RadioGroup radioSexGroup;
    private RadioButton radioSexButton;
    private Button btnDisplay;
    public String result = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_4);

        mTextView = (TextView) findViewById(R.id.text);


        Intent intent = getIntent();
        String value = intent.getStringExtra("key"); //if it's a string you stored.
        score = Integer.parseInt(value);

        // Enables Always-on
        setAmbientEnabled();

        btnDisplay = (Button) findViewById(R.id.button);

        // Enables Always-on
        setAmbientEnabled();

        btnDisplay.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                result = addListenerOnButton();
                check_answer(result);
            }
        });
    }



    public void check_answer(String a)
    {
        if (a == "B2")
        {
            score = score + 1;

            Intent myIntent = new Intent(Question_4.this, Question_5.class);
            myIntent.putExtra("key", score); //Optional parameters
            Question_4.this.startActivity(myIntent);
        }
    }


    public String addListenerOnButton()
    {

        radioSexGroup = (RadioGroup) findViewById(R.id.radioGroup);
        btnDisplay = (Button) findViewById(R.id.button);

        btnDisplay.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)

            {
                // get selected radio button from radioGroup
                option_number = radioSexGroup.getCheckedRadioButtonId();

                result = Integer.toString(option_number);

            }

        });

        return result;
    }
}
